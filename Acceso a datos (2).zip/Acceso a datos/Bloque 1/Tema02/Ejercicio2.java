package Tema02;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Scanner;

import javafx.scene.shape.Line;

public class Ejercicio2 {

    
    
    public static void main(String[] args) {
        
        String ruta = "C:\\Users\\PC104\\Desktop\\Acceso a datos\\Bloque 1\\Tema02\\Ejemplos\\entrada2.txt";

        try ( Scanner sc = new Scanner(System.in)){
            
            System.out.println("Indica que linea quieres leer : ");

            int lineaDeseada = sc.nextInt();

            if (lineaDeseada <= 0) {
                System.out.println("El número de línea debe ser mayor a 0.");
                return;
        }
        
        try (LineNumberReader lnr = new LineNumberReader(new FileReader(ruta))){
            String linea;
            boolean encontrada = true;

            while ((linea = lnr.readLine()) != null) {
                    // LineNumberReader lleva el conteo automático de líneas (empieza en 1)
                    if (lnr.getLineNumber() == lineaDeseada) {
                        System.out.println("Contenido de la línea número " + lineaDeseada + ":");
                        System.out.println(linea);
                        encontrada = true;
                        break; // Terminamos la lectura al encontrar la línea
                    }
                }

                if (!encontrada) {
                    System.out.println("La línea número " + lineaDeseada + " no existe en el archivo.");
                }

            } catch (IOException e) {
                System.err.println("Error al leer el archivo: " + e.getMessage());
            }
        
        } catch (Exception e) {
            
            System.out.println("El numero de linea no existe.");
        }


    }
}


