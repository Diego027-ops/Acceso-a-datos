package Tema02;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class Ejemplo2 {
    public static void main(String[] args) throws Exception {

        try {
            LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(".\\Tema02\\Ejemplos\\datos.txt"));
            String line;
            while((line = lineNumberReader.readLine()) != null) {
                System.out.println("Contenido de la linea numero:"+ lineNumberReader.getLineNumber());
                System.out.println(line);
            }
                lineNumberReader.close();

            } catch (IOException e) {
            e.printStackTrace();
            }
    }
}



