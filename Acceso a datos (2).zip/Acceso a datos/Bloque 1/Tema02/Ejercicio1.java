package Tema02;

import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.StreamTokenizer;
import java.io.StringReader;

public class Ejercicio1 {

    public static void main(String[] args) {

        String ruta = "C:\\Users\\PC104\\Desktop\\Acceso a datos\\Bloque 1\\Tema02\\Ejemplos\\entrada.txt";

    try (LineNumberReader lnr = new LineNumberReader(new FileReader(ruta))){

        String linea;

        while ((linea = lnr.readLine()) != null) {
            
            int palabras = 0;
            int numeros = 0;

            StreamTokenizer tokenizer = new StreamTokenizer(new StringReader(linea));

            int token;

            while ((token = tokenizer.nextToken()) != StreamTokenizer.TT_EOF) {
              
                if (token == StreamTokenizer.TT_WORD ) {
                    palabras++;
                } else {
                    numeros++;
                }
            } 

            System.out.println("Linea " + lnr.getLineNumber() + ": " + linea);
            System.out.println("Palabras " + palabras + ", Numeros : " + numeros);
            System.out.println();

        }

    } catch (Exception e) {

        System.err.println("Error al leer el archivo: " + e.getMessage());
       
    }

}
}
