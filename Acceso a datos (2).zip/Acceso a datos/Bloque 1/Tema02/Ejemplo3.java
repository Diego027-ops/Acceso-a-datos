package Tema02;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Ejemplo3 {
    public static void main(String[] args) {
        try {

            DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(".\\Tema02\\Ejemplos\\salida.txt"));
            dataOutputStream.writeInt(123);
            dataOutputStream.writeInt(987);
            dataOutputStream.writeFloat(123.45F);
            dataOutputStream.writeLong(789);
            dataOutputStream.writeDouble(9.3);
            dataOutputStream.close();

            DataInputStream dataInputStream = new DataInputStream(new FileInputStream(".\\Tema02\\Ejemplos\\salida.txt"));
            int entero = dataInputStream.readInt();
            int entero1 = dataInputStream.readInt();
            float numeroFloat = dataInputStream.readFloat();
            double numerodouble = dataInputStream.readDouble();
            long numeroLong = dataInputStream.readLong();
            dataInputStream.close();
            System.out.println("El objeto de tipo float es: "+numeroFloat);
            System.out.println("El número entero es: "+entero);

            System.out.println("El double es :"+numerodouble);
            System.out.println("El objeto long es: "+numeroLong);


            } catch (FileNotFoundException e) {
            e.printStackTrace();
            } catch (IOException e) {
            e.printStackTrace();
            }
    }
}