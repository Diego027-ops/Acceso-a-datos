package Tema02;
import java.io.FileReader;
import java.io.IOException;
import java.io.StreamTokenizer;

public class Ejemplo1 {

    public static void main(String[] args) {
        
        // Configurar para que el carácter de nueva línea sea significativo


        try {
            
            StreamTokenizer streamTokenizer = new StreamTokenizer(new FileReader("./TEMA02/Ejemplos/datos.txt"));
            streamTokenizer.eolIsSignificant(true);

            while(streamTokenizer.nextToken() != StreamTokenizer.TT_EOF){
                if(streamTokenizer.ttype == StreamTokenizer.TT_WORD) {
                    System.out.println("Palabras - "+streamTokenizer.sval);
                } else if(streamTokenizer.ttype == StreamTokenizer.TT_NUMBER) {
                    System.out.println("number - "+streamTokenizer.nval);
                } else if(streamTokenizer.ttype == StreamTokenizer.TT_EOL) {
                    System.out.println("Fin");
                }
        }
        } catch (IOException e) {
        e.printStackTrace();
        }

    }
}