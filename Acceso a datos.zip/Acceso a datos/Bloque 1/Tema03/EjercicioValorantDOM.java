package Tema03;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/*
 ESTRUCTURA DEL XML DE VALORANT:
 
 - Raíz: valorant engloba todo el documento.
 
 - agentes: Lista de personajes jugables.
        Atributos: 'id' (ej. A01).
        Elementos: <nombre>, <rol>, <origen> y <habilidades>.
 -habilidad: Tiene atributo 'tipo' (Básica, Firma, Definitiva).
  
 -armas: Catálogo de compra.
 Atributos: 'id' (ej. W01) y 'categoria' (Rifle, Francotirador, etc.).
 Elementos: <nombre>, <precio> y <cargador>.
 
  - mapas: Escenarios de juego.
        Atributo: 'id' (ej. M01).
        Elementos: <nombre>, <ubicacion> y <sitiosBombas>.
  
  - Criterio clave: Atributos = metadatos/IDs | Elementos = datos principales.
 */

public class EjercicioValorantDOM {

    public static void main(String[] args) {
        File archivo = new File("C:\\Users\\PC104\\Desktop\\Acceso a datos\\Bloque 1\\Tema03\\Ejemplos\\Valorant.xml"); // O "valorant.xml"

        try {
            // 1. Inicializar el parser DOM
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();

            // 2. Cargar el XML en memoria
            Document doc = builder.parse(archivo);
            doc.getDocumentElement().normalize();

            System.out.println("=== CATÁLOGO DE VALORANT (DOM) ===\n");

            // ----------------------------------------------------
            // SECCIÓN 1: AGENTES
            // ----------------------------------------------------
            NodeList listaAgentes = doc.getElementsByTagName("agente");
            int totalAgentes = listaAgentes.getLength();

            System.out.println("--- AGENTES ---");
            for (int i = 0; i < totalAgentes; i++) {
                Node nodo = listaAgentes.item(i);

                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    Element elem = (Element) nodo;

                    // Atributo ID y etiquetas hijas
                    String id = elem.getAttribute("id");
                    String nombre = elem.getElementsByTagName("nombre").item(0).getTextContent();
                    String rol = elem.getElementsByTagName("rol").item(0).getTextContent();
                    String origen = elem.getElementsByTagName("origen").item(0).getTextContent();

                    System.out.println("Agente [" + id + "]: " + nombre);
                    System.out.println("  - Rol: " + rol);
                    System.out.println("  - Origen: " + origen);

                    // Habilidades del agente
                    NodeList listaHabilidades = elem.getElementsByTagName("habilidad");
                    System.out.println("  - Habilidades:");
                    for (int j = 0; j < listaHabilidades.getLength(); j++) {
                        Element elemHab = (Element) listaHabilidades.item(j);
                        String tipo = elemHab.getAttribute("tipo");
                        String habNombre = elemHab.getTextContent();
                        System.out.println("    * " + habNombre + " (" + tipo + ")");
                    }
                    System.out.println();
                }
            }
            System.out.println("Total de Agentes: " + totalAgentes + "\n");

            // ----------------------------------------------------
            // SECCIÓN 2: ARMAS
            // ----------------------------------------------------
            NodeList listaArmas = doc.getElementsByTagName("arma");
            int totalArmas = listaArmas.getLength();

            System.out.println("--- ARMAS ---");
            for (int i = 0; i < totalArmas; i++) {
                Node nodo = listaArmas.item(i);

                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    Element elem = (Element) nodo;

                    String id = elem.getAttribute("id");
                    String categoria = elem.getAttribute("categoria");
                    String nombre = elem.getElementsByTagName("nombre").item(0).getTextContent();
                    String precio = elem.getElementsByTagName("precio").item(0).getTextContent();
                    String cargador = elem.getElementsByTagName("cargador").item(0).getTextContent();

                    System.out.println("Arma [" + id + "]: " + nombre + " (" + categoria + ")");
                    System.out.println("  - Precio: " + precio + " Creds");
                    System.out.println("  - Cargador: " + cargador + " balas");
                    System.out.println();
                }
            }
            System.out.println("Total de Armas + totalArmas" + "\n");

        } catch (Exception e) {
            System.err.println("Error al procesar el archivo XML: " + e.getMessage());
            e.printStackTrace();
        }
    }
}