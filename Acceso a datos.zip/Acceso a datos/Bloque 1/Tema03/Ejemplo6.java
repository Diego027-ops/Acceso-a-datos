package Tema03;

public class Ejemplo6 {
    
public static void main(String[] args) {
    
    try {
        
    
    String texto = null;
    int longitud =texto.length();
    System.out.println(longitud);

} catch (Exception e) {

        // TODO: handle exception

        System.out.println("Excepción controlada: ");
        e.getMessage();

    }


}

}
