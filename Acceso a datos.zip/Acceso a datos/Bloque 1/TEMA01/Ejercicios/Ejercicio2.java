package TEMA01.Ejercicios;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Ejercicio2 {
    
    //Copiar una imagen y contar bytes con FileInputStream

    public static void main(String[] args) {
        

        String origen = "foto.jpg";
        String destinoByte = "foto_copia.jpg";
        int contador = 0;

        try (FileInputStream fis = new FileInputStream(origen);
             FileOutputStream fos = new FileOutputStream(destinoByte)) {

            int byteLeido;
            while ((byteLeido = fis.read()) != -1) {
                fos.write(byteLeido);
                contador++; // Contador incrementado por cada byte
            }
            System.out.println("Bytes leídos y copiados con Stream: " + contador);

        } catch (IOException e) {
            System.err.println("Error en copia binaria: " + e.getMessage());
        }

        // --- PARTE 2 (Punto 8): Con Readers/Writers orientados a Caracteres ---
        String destinoChar = "foto_copia_text.jpg";
        try (FileReader fr = new FileReader(origen);
             FileWriter fw = new FileWriter(destinoChar)) {

            int c;
            while ((c = fr.read()) != -1) {
                fw.write(c);
            }
            System.out.println("Copia con FileReader/FileWriter finalizada.");

        } catch (IOException e) {
            System.err.println("Error en copia de texto: " + e.getMessage());
        }


    }
}
