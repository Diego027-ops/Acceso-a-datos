package TEMA01.Ejercicios;
import java.io.RandomAccessFile;

//Ejemplo de acceso aleatorio o directo

public class Ejemplo6 {

    public static void main(String[] args) {

        try {
            RandomAccessFile file = new RandomAccessFile("./TEMA01/Ejemplos/texto.txt", "rw");
            file.seek(5);
            long filePointer = file.getFilePointer();
            int unByte = file.read();

            System.out.println((char) unByte);
            System.out.println(filePointer);
            file.write('X');
            file.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

