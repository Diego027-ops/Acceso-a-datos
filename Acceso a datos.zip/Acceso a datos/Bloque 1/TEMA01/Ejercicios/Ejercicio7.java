package TEMA01.Ejercicios;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Ejercicio7 {
    public static void main(String[] args) {
        // Misma ruta relativa que en el ejercicio anterior
        String rutaArchivo = "./TEMA01/Ejemplos/NuevaCarpeta/Asientos.txt";

        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Introduce la posición inicial a consultar : ");
            int posInicial = sc.nextInt();

            System.out.print("¿Cuántos asientos deseas consultar a partir de ahí? : ");
            int cantidad = sc.nextInt();

            String asientosActuales = "";

            // Lectura del fichero utilizando BufferedReader
            try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
                asientosActuales = br.readLine();
            } catch (IOException e) {
                System.err.println("Error al leer el archivo de asientos (" + rutaArchivo + "): " + e.getMessage());
                return;
            }

            // Verificación de que el contenido no es nulo y que el rango a consultar no excede la cantidad de asientos
            if (asientosActuales == null || posInicial < 0 || (posInicial + cantidad) > asientosActuales.length()) {
                System.out.println("El rango introducido sobrepasa los límites o el tamaño de la sala.");
                return;
            }

            // Muestra del rango seleccionado
            System.out.println("\nEstado de los asientos en el rango solicitado:");
            for (int i = 0; i < cantidad; i++) {
                int numAsiento = posInicial + i;
                char estado = asientosActuales.charAt(numAsiento);
                System.out.println("Asiento " + numAsiento + ": " + estado);
            }

        } catch (Exception e) {
            System.err.println("Error durante la lectura/procesamiento: " + e.getMessage());
        }
    }
}
