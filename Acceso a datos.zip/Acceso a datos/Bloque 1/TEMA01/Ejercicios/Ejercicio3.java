package TEMA01.Ejercicios;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class Ejercicio3 {
    
    // Modificar datos en un archivo de texto (RandomAccessFile)

    public static void main(String[] args) {
     
            // 1. Escribir el abecedario mediante FileWriter
            
        try (FileWriter fw = new FileWriter(archivo)) {
            fw.write("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
            System.out.println("Abecedario escrito en " + archivo);
        } catch (IOException e) {
            System.err.println("Error al inicializar el fichero: " + e.getMessage());
            return;
        }

        // Pedir datos al usuario
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Introduce la posición (0-25) a modificar: ");
            int pos = sc.nextInt();

            System.out.print("Introduce el nuevo carácter: ");
            char nuevoChar = sc.next().charAt(0);

            // 4. Usar RandomAccessFile para posicionarse y sobrescribir
            try (RandomAccessFile raf = new RandomAccessFile(archivo, "rw")) {
                if (pos < 0 || pos >= raf.length()) {
                    System.out.println("Error: La posición introducida no es válida.");
                } else {
                    raf.seek(pos); // Posicionarse
                    raf.writeByte((byte) nuevoChar); // Sobrescribir el carácter
                    System.out.println("Posición " + pos + " modificada con éxito.");
                }
            } catch (IOException e) {
                System.err.println("Error al acceder o modificar el fichero: " + e.getMessage());
            }
        }


    }
}
