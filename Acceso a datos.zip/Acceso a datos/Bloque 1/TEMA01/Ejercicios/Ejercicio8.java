package TEMA01.Ejercicios;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Ejercicio8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String archivo = "matricula.txt";

        System.out.println("=== FORMULARIO DE MATRICULACIÓN ===");
        System.out.println("1. Guardar");
        System.out.println("2. Imprimir");
        System.out.print("Elige una opción: ");
        
        int opcion = sc.nextInt();
        sc.nextLine(); // Limpiar el buffer del scanner tras leer un int

        if (opcion == 1) {
            // Pide por teclado todos los datos del formulario
            System.out.print("Nombre y Apellidos: ");
            String nombre = sc.nextLine();

            System.out.print("Email: ");
            String email = sc.nextLine();

            System.out.print("Fecha de Nacimiento (DD/MM/AAAA): ");
            String fechaNacimiento = sc.nextLine();

            System.out.print("Género (Masculino / Femenino): ");
            String genero = sc.nextLine();

            System.out.print("Titulación de Acceso (FP Grado Medio / FP Grado Superior / Bachillerato): ");
            String titulacion = sc.nextLine();

            System.out.print("Observaciones: ");
            String observaciones = sc.nextLine();

            // Une todos los datos recogidos respetando el formato solicitado
            String contenido = "----- Formulario de Matriculación -----\n" +
                    "Nombre y Apellidos: " + nombre + "\n" +
                    "Email: " + email + "\n" +
                    "Fecha de Nacimiento: " + fechaNacimiento + "\n" +
                    "Género: " + genero + "\n" +
                    "Titulación de Acceso: " + titulacion + "\n" +
                    "Observaciones:\n" + observaciones + "\n" +
                    "---------------------------------------";

            // Escribe el String en el fichero matricula.txt usando FileWriter
            try (FileWriter fw = new FileWriter(archivo)) {
                fw.write(contenido);
                System.out.println("\nMatrícula guardada correctamente en " + archivo);
            } catch (IOException e) {
                System.err.println("Error de escritura en el archivo: " + e.getMessage());
            }

        } else if (opcion == 2) {
            // Lee el contenido de matricula.txt y lo muestra por pantalla
            try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                System.out.println("\n--- CONTENIDO DEL FORMULARIO GUADARDO ---");
                String linea;
                while ((linea = br.readLine()) != null) {
                    System.out.println(linea);
                }
            } catch (IOException e) {
                System.err.println("Error de lectura en el archivo (asegúrate de haber guardado uno antes): " + e.getMessage());
            }
        } else {
            System.out.println("Opción no válida.");
        }
    }
}