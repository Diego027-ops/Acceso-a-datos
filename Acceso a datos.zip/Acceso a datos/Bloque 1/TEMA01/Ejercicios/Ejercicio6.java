package TEMA01.Ejercicios;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Ejercicio6 {
    public static void main(String[] args) {
        // Ruta relativa exacta del archivo .txt en la raíz del proyecto
        String rutaArchivo = "./TEMA01/Ejemplos/NuevaCarpeta/Asientos.txt";

        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Introduce el número de asiento que deseas comprar (0-19): ");
            int asiento = sc.nextInt();

            // 1. Validación de rango (0-19)
            if (asiento < 0 || asiento > 19) {
                System.out.println("Ese asiento no existe o no está disponible.");
                return;
            }

            String asientosActuales = "";

            // 2. Lectura del fichero utilizando BufferedReader con la ruta específica
            try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
                asientosActuales = br.readLine();
            } catch (IOException e) {
                System.err.println("Error al leer el archivo de asientos (" + rutaArchivo + "): " + e.getMessage());
                return;
            }

            // Verificación de validez del contenido leído
            if (asientosActuales == null || asientosActuales.length() <= asiento) {
                System.out.println("El fichero no tiene el formato o la cantidad de asientos requerida.");
                return;
            }

            // 3. Comprobación del estado actual del asiento
            char estadoActual = asientosActuales.charAt(asiento);

            if (estadoActual == 'C') {
                System.out.println("El asiento " + asiento + " ya está ocupado.");
            } else if (estadoActual == 'L') {
                // Modificación en memoria del asiento seleccionado
                char[] arrayAsientos = asientosActuales.toCharArray();
                arrayAsientos[asiento] = 'C';

                // 4. Sobrescribir el fichero con la nueva información
                try (FileWriter fw = new FileWriter(rutaArchivo)) {
                    fw.write(arrayAsientos);
                    System.out.println("Asiento " + asiento + " reservado con éxito.");
                } catch (IOException e) {
                    System.err.println("Error al actualizar el fichero: " + e.getMessage());
                }
            } else {
                System.out.println("Estado de asiento desconocido (" + estadoActual + ").");
            }

        } catch (Exception e) {
            System.err.println("Error en el procesamiento: " + e.getMessage());
        }
    }
}
