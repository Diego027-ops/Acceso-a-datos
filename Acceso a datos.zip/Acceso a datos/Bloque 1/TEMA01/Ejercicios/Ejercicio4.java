package TEMA01.Ejercicios;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Ejercicio4 {
    
    //Copiar un fichero con buffers

    public static void main(String[] args) {
        
        String origen = "foto.jpg";
        String destino = "foto_copia_buffer.jpg";
        byte[] buffer = new byte[1024]; // Buffer de 1024 bytes
        int bytesLeidos;
        int bloque = 1;

        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(origen));
             BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(destino))) {

            while ((bytesLeidos = bis.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesLeidos);
                System.out.println("Fin copia bloque " + bloque);
                bloque++;
            }
            System.out.println("Copia finalizada correctamente.");

        } catch (IOException e) {
            System.err.println("Error durante la copia con buffer: " + e.getMessage());
        }


    }
}
