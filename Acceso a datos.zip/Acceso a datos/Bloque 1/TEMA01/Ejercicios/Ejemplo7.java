package TEMA01.Ejercicios;
import java.io.RandomAccessFile;
import java.io.IOException;

public class Ejemplo7 {
    
    public static void main(String[] args) {
 

        try {

            RandomAccessFile File = new RandomAccessFile("./TEMA01/Ejemplos/abcd.txt","r");

             File.seek(5);

             byte[] arrayByte = new byte[3];

             File.read(arrayByte, 0, 3);

            System.out.println("Bytes leidos : " + arrayByte.length);
            System.out.println("Puntero despues de read : " + File.getFilePointer());

            for(int i = 0; i< arrayByte.length; i++){

                System.out.println("  arrayBytes[" + i + "] = " + arrayByte[i] + " -> '" + (char) arrayByte[i] + "'");

            }
            File.close();
            
        } catch (Exception e) {
            // TODO: handle exception
        }
       


    }
}
