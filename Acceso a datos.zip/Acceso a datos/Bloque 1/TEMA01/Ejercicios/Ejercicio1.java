package TEMA01.Ejercicios;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Ejercicio1 {

    //Copiar texto de un fichero a otro

    public static void main(String[] args) {
        
        // Rutas de los archivos
        String origen = "texto.txt";
        String destino = "copia.txt";

        // Paso 1, 2, 3 y 4: Uso de try-with-resources para asegurar el cierre de ficheros
        try (FileReader fr = new FileReader(origen);
             FileWriter fw = new FileWriter(destino)) {

            int c;
            // Lectura carácter a carácter
            while ((c = fr.read()) != -1) {
                fw.write(c); // Escritura inmediata
            }
            System.out.println("Copia realizada con éxito de " + origen + " a " + destino);

        } catch (IOException e) {
            System.err.println("Error de lectura/escritura o archivo no encontrado: " + e.getMessage());
        }
    }
}
