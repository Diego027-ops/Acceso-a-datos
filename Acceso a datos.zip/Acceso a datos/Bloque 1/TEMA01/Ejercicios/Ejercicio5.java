package TEMA01.Ejercicios;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class Ejercicio5 {
    public static void main(String[] args) {
        
        BufferedInputStream entrada = new BufferedInputStream(new FileInputStream(origen2));
        BufferedOutputStream salida = new BufferedOutputStream(new FileOutputStream("./Nloque1/Ejemplos") {
            
        })

}
}